# Wiring Guide

## Connections

| DHT11 pin | ESP32 pin | Purpose |
|---|---|---|
| VCC / + | **3V3** | Power (3.3 V) |
| DATA / S / OUT | **GPIO 4** | Sensor signal |
| GND / - | **GND** | Ground |

**Why GPIO 4?** It is a normal input/output pin with no special boot behaviour, so it will not interfere with uploading code.

## Module (3 pins) vs bare sensor (4 pins)

| Type | Looks like | Pull-up resistor |
|---|---|---|
| **DHT11 module** | Small PCB with 3 pins, labels like `+`, `-`, `S` / `OUT` | Already on the PCB. Add nothing. |
| **Bare DHT11** | Blue plastic box with a grid and 4 pins | Add a **10 kΩ** resistor between **VCC and DATA** |

**Module:** read the tiny labels on the PCB. The order differs between makers, so do not assume.

**Bare sensor:** hold it with the grid facing you and pins pointing down. Left to right:
1. VCC
2. DATA
3. NC (not connected, leave empty)
4. GND

## ASCII diagram

```
   ESP32 DevKit V1                     DHT11 module
  ┌──────────────┐                  ┌──────────────┐
  │          3V3 ├──────────────────┤ VCC (+)      │
  │       GPIO 4 ├──────────────────┤ DATA (S/OUT) │
  │          GND ├──────────────────┤ GND (-)      │
  │      [USB]   │                  └──────────────┘
  └──────────────┘

  Bare 4-pin sensor:
   3V3 ──┬──────────── Pin 1 VCC
       [10 kΩ]
  GPIO 4 ┴──────────── Pin 2 DATA
                       Pin 3 NC (leave empty)
   GND ──────────────── Pin 4 GND
```

A graphical version is in [`circuit-diagram.svg`](circuit-diagram.svg).

## Breadboard steps (USB unplugged)

1. Place the DHT11 on the breadboard so each pin is in its own row.
2. Jumper **3V3 → DHT11 VCC**.
3. Jumper **GND → DHT11 GND**.
4. Jumper **GPIO 4 → DHT11 DATA**.
5. Bare sensor only: put the 10 kΩ resistor between the VCC row and the DATA row.

## Check before powering on

- Compare each wire with the table above, one at a time.
- No two wires share a breadboard row by mistake.
- VCC is not touching GND. With a multimeter in continuity mode, VCC and GND must **not** beep.
- Then plug in the USB cable.

## Common mistakes

- VCC and GND swapped (can damage the sensor).
- Assuming the module pin order instead of reading the labels.
- Bare sensor without the pull-up resistor (gives `NaN`).
- Loose jumper wires.
- Using a charge-only USB cable.

## Safety

Wire with the USB unplugged, keep liquids away from the board, and use 3.3 V for the sensor.
