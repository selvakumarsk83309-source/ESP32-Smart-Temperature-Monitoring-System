# Components

| # | Component | Qty | Notes |
|---|---|---|---|
| 1 | ESP32 DevKit V1 (38-pin) | 1 | Wi-Fi microcontroller |
| 2 | DHT11 temperature & humidity sensor | 1 | Either a 3-pin **module** or a bare 4-pin sensor |
| 3 | Breadboard | 1 | Half-size is enough |
| 4 | Jumper wires (male-male / male-female) | 3 | Male-female if your module has header pins |
| 5 | USB cable (data-capable) | 1 | Charge-only cables will not work |
| 6 | Laptop (Windows 11) | 1 | Runs the backend and dashboard |
| 7 | 10 kΩ resistor | 1 | **Only for a bare 4-pin DHT11.** Not needed for a module |
| 8 | Multimeter | 1 | **OPTIONAL** - for checking connections |

## DHT11 at a glance

- Supply: 3.3 V to 5 V (use **3.3 V** with the ESP32)
- Temperature range: about 0 to 50 °C, accuracy about ±2 °C
- Humidity range: about 20 to 90 %, accuracy about ±5 %
- Needs at least about 1 second between readings (this project reads every 10 s)

Values are typical datasheet figures; check the datasheet of your exact part.
