# Screenshots

Add your own screenshots here after you run the project. Suggested files:

| File name | What to capture |
|---|---|
| `dashboard-desktop.png` | Full dashboard with real data on a laptop/desktop browser |
| `dashboard-mobile.png` | Dashboard in a mobile-sized browser window (F12, then Ctrl + Shift + M) |
| `serial-monitor.png` | Arduino Serial Monitor showing readings and `Server response: 201` |
| `wiring.jpg` | Photo of your breadboard wiring |
| `database.png` | (optional) DB Browser for SQLite showing the `sensor_readings` table |

Then reference them in the main `README.md`, for example:

```markdown
![Dashboard](screenshots/dashboard-desktop.png)
```

Only add screenshots of your real setup. Make sure they do not show your Wi-Fi password or personal information.
