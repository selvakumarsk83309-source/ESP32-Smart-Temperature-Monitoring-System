# Database

The project uses **SQLite**, a database stored in a single file. You do **not** need to install SQLite or any database server.

## How it is created

When you run `npm start` inside `backend/`, `backend/database.js`:

1. creates the folder `backend/data/` if it does not exist,
2. creates (or opens) the file `backend/data/sensor.db`,
3. runs `database/schema.sql` to create the table if it is missing.

The `.db` file is ignored by Git (`.gitignore`), so your local data is never uploaded.

## Table: `sensor_readings`

| Column | Type | Meaning |
|---|---|---|
| `id` | INTEGER, PRIMARY KEY AUTOINCREMENT | Unique number for each reading |
| `temperature` | REAL, NOT NULL | Temperature in °C |
| `humidity` | REAL, NOT NULL | Relative humidity in % |
| `created_at` | TEXT, NOT NULL, default `datetime('now')` | Time the backend saved the reading, in **UTC** (`YYYY-MM-DD HH:MM:SS`) |

## How data moves

- **Insert:** `POST /api/sensor` validates the JSON, then runs `INSERT INTO sensor_readings (temperature, humidity) VALUES (?, ?)`.
- **Read newest:** `GET /api/sensor/latest` runs `SELECT ... ORDER BY id DESC LIMIT 1`.
- **Read history:** `GET /api/sensor/history?limit=50` runs `SELECT ... ORDER BY id DESC LIMIT ?`.

## Add sample / test data

Start the backend first (`cd backend`, `npm start`), then use a second terminal.

**Command Prompt:**
```
curl -X POST http://localhost:3000/api/sensor -H "Content-Type: application/json" -d "{\"temperature\":27.5,\"humidity\":60}"
```

**PowerShell (adds 10 readings):**
```powershell
1..10 | ForEach-Object {
  $body = @{ temperature = (24 + (Get-Random -Minimum 0 -Maximum 80) / 10); humidity = (50 + (Get-Random -Minimum 0 -Maximum 200) / 10) } | ConvertTo-Json
  Invoke-RestMethod -Method Post -Uri http://localhost:3000/api/sensor -ContentType "application/json" -Body $body
  Start-Sleep -Seconds 1
}
```

## Check that data is stored

- Open <http://localhost:3000/api/sensor/history> in your browser, or
- (optional) open `backend/data/sensor.db` in **DB Browser for SQLite** or the VS Code **SQLite Viewer** extension.

## Reset the database (development only)

1. Stop the server with `Ctrl + C`.
2. Delete `backend/data/sensor.db`.
3. Run `npm start` again; a fresh empty database is created.
