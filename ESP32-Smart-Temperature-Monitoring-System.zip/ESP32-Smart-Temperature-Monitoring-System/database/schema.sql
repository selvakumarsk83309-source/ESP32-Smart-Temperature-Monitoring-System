-- Database schema for the ESP32 Smart Temperature Monitoring System.
-- This file is executed automatically by backend/database.js every time the
-- backend starts. "IF NOT EXISTS" makes it safe to run repeatedly.

CREATE TABLE IF NOT EXISTS sensor_readings (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,  -- unique number for each reading
    temperature REAL    NOT NULL,                   -- degrees Celsius
    humidity    REAL    NOT NULL,                   -- relative humidity in percent
    created_at  TEXT    NOT NULL DEFAULT (datetime('now'))  -- UTC time: YYYY-MM-DD HH:MM:SS
);

-- Speeds up "newest readings first" queries.
CREATE INDEX IF NOT EXISTS idx_sensor_readings_created_at
    ON sensor_readings (created_at);
