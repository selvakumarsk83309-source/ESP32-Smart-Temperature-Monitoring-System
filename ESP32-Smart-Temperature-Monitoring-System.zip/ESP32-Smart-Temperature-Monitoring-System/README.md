# ESP32 Smart Temperature Monitoring System

Real-time IoT temperature and humidity monitoring with an ESP32, a DHT11 sensor, a Node.js + Express backend, an SQLite database and a responsive web dashboard. Everything runs locally on a Windows laptop. No cloud account or paid service is needed.

## Overview

An ESP32 reads temperature and humidity from a DHT11 sensor and sends the values over Wi-Fi to a REST API. The backend validates and stores each reading in SQLite. A browser dashboard shows the current values, status, charts and a table of recent readings, and refreshes automatically.

## Features

- ESP32 Wi-Fi connection with automatic reconnect
- DHT11 temperature (°C) and humidity (%) reading with validation
- HTTP POST of JSON to the backend every 10 seconds
- REST API with input validation and proper HTTP status codes
- SQLite storage created automatically on first start
- Dark responsive dashboard: current values, temperature and humidity status, last update time, history charts, recent readings table
- Backend, ESP32 and sensor status indicators
- Loading, empty and error states
- Easy-to-change thresholds and refresh interval

## Technologies Used

| Area | Technology |
|---|---|
| Hardware | ESP32 DevKit V1, DHT11 |
| Firmware | Arduino IDE, C/C++, WiFi.h, HTTPClient.h, Adafruit DHT library |
| Backend | Node.js, Express.js, better-sqlite3, cors, dotenv |
| Database | SQLite |
| Frontend | HTML5, CSS3, JavaScript, Chart.js (CDN) |

## Hardware Requirements

ESP32 DevKit V1 (38-pin), DHT11, breadboard, jumper wires, USB data cable, laptop. A 10 kΩ resistor is needed **only** for a bare 4-pin DHT11 (modules include it). A multimeter is OPTIONAL. See [`hardware/components.md`](hardware/components.md).

## Software Requirements

Windows 11, Node.js LTS, VS Code, Git, Arduino IDE 2.x with "esp32 by Espressif Systems" and the Adafruit "DHT sensor library" + "Adafruit Unified Sensor".

## Circuit Connection

| DHT11 pin | ESP32 pin |
|---|---|
| VCC / + | 3V3 |
| DATA / S / OUT | GPIO 4 |
| GND / - | GND |

Diagram: [`hardware/circuit-diagram.svg`](hardware/circuit-diagram.svg). Full guide: [`hardware/wiring.md`](hardware/wiring.md).

## Architecture

```
DHT11 → ESP32 → Wi-Fi → Node.js + Express → REST API → SQLite → Browser dashboard
```

1. The **DHT11** measures temperature and humidity.
2. The **ESP32** reads it on GPIO 4 and connects to Wi-Fi.
3. It sends `{"temperature":27.5,"humidity":60.0}` to `http://<laptop IP>:3000/api/sensor`.
4. **Express** validates the data and the **SQLite** table `sensor_readings` stores it.
5. The **dashboard** calls `GET /api/sensor/latest` and `GET /api/sensor/history` every 5 seconds.

## Project Structure

```
ESP32-Smart-Temperature-Monitoring-System/
├── README.md  LICENSE  .gitignore
├── hardware/    circuit-diagram.svg, wiring.md, components.md
├── esp32/       temperature_monitor.ino, README.md
├── backend/     package.json, server.js, database.js, .env.example, routes/sensorRoutes.js
├── database/    schema.sql, README.md
├── frontend/    index.html, css/style.css, js/script.js
├── docs/        PROJECT_REPORT.md, API_DOCUMENTATION.md, TROUBLESHOOTING.md, INTERVIEW_QUESTIONS.md
└── screenshots/ README.md
```

## Installation

Install Node.js LTS (<https://nodejs.org>), Git (<https://git-scm.com>), VS Code (<https://code.visualstudio.com>) and Arduino IDE 2.x (<https://www.arduino.cc/en/software>). Verify in Command Prompt:

```
node --version
npm --version
git --version
```

Clone the project (replace `YOUR_GITHUB_USERNAME`):

```
git clone https://github.com/YOUR_GITHUB_USERNAME/ESP32-Smart-Temperature-Monitoring-System.git
cd ESP32-Smart-Temperature-Monitoring-System
```

## ESP32 Setup

Follow [`esp32/README.md`](esp32/README.md). In short: install ESP32 board support and the two libraries, select **ESP32 Dev Module** and your COM port, edit `WIFI_SSID`, `WIFI_PASSWORD` and `SERVER_URL` (use your laptop IPv4 from `ipconfig`, **never** `localhost`), upload, and open the Serial Monitor at **115200** baud.

## Backend Setup

```
cd backend
npm install
npm start
```

Expected output:

```
Server running on http://localhost:3000
```

A `.env` file is optional. To customise the port: `copy .env.example .env`.

Allow Node.js through Windows Firewall on **Private** networks (or run, in an Administrator PowerShell):

```
New-NetFirewallRule -DisplayName "Node 3000" -Direction Inbound -Protocol TCP -LocalPort 3000 -Action Allow -Profile Private
```

## Database Setup

Nothing to install. `backend/data/sensor.db` is created automatically from [`database/schema.sql`](database/schema.sql) when the backend starts. See [`database/README.md`](database/README.md) for test data and reset steps.

## Frontend Setup

Nothing to install. Express serves the `frontend/` folder, so just open <http://localhost:3000/>. Charts load Chart.js from a CDN, so the laptop needs internet access for the charts.

## Running the Project

1. Start the backend (`cd backend`, `npm start`).
2. Open <http://localhost:3000/>. The dashboard shows an empty state until data arrives.
3. Test without hardware (Command Prompt):
   ```
   curl -X POST http://localhost:3000/api/sensor -H "Content-Type: application/json" -d "{\"temperature\":27.5,\"humidity\":60}"
   ```
4. Power the ESP32. Within about 10 seconds the dashboard shows real readings.

## API Endpoints

| Method | URL | Purpose |
|---|---|---|
| GET | `/` | Dashboard |
| GET | `/api/health` | Backend health check |
| POST | `/api/sensor` | Save a reading |
| GET | `/api/sensor/latest` | Newest reading |
| GET | `/api/sensor/history?limit=50` | Recent readings, newest first |

Details and examples: [`docs/API_DOCUMENTATION.md`](docs/API_DOCUMENTATION.md).

## Screenshots

Add your own screenshots to [`screenshots/`](screenshots/README.md) after running the project, then link them here.

## Troubleshooting

See [`docs/TROUBLESHOOTING.md`](docs/TROUBLESHOOTING.md). The most common problems: using `localhost` in the ESP32 code, a wrong laptop IP, Windows Firewall blocking port 3000, and the DHT11 returning `NaN` because of wiring.

## Future Enhancements

OLED display, MQTT, Blynk or other cloud integration, mobile app, email alerts, threshold alerts, multiple ESP32 devices, authentication, cloud database, OTA updates, CSV data export, more accurate sensors (DHT22 / BME280).

## Learning Outcomes

- Interfacing a digital sensor with a microcontroller
- Wi-Fi and HTTP communication from an ESP32
- Designing and validating a REST API
- Using SQLite from Node.js
- Building a responsive dashboard with `fetch` and Chart.js
- Testing and troubleshooting an end-to-end IoT system

## Author

Author: [Your Name]

License: MIT (see [`LICENSE`](LICENSE))
