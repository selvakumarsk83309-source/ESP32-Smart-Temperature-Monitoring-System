/**
 * sensorRoutes.js
 * All routes under /api/sensor
 *   POST /api/sensor           - save a new reading (called by the ESP32)
 *   GET  /api/sensor/latest    - newest reading (used by the dashboard cards)
 *   GET  /api/sensor/history   - recent readings, newest first (charts + table)
 */
const express = require('express');
const database = require('../database');

const router = express.Router();

// Validation limits. Humidity must be 0-100 %. The temperature range is a
// generous "is this physically sensible?" check, not a DHT11 specification.
const LIMITS = { TEMP_MIN: -40, TEMP_MAX: 125, HUMIDITY_MIN: 0, HUMIDITY_MAX: 100 };
const DEFAULT_HISTORY_LIMIT = 50;
const MAX_HISTORY_LIMIT = 500;

/** Returns a list of error messages. An empty list means the data is valid. */
function validateReading(body) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) {
    return ['Request body must be a JSON object with temperature and humidity'];
  }
  const errors = [];
  const { temperature, humidity } = body;

  if (typeof temperature !== 'number' || !Number.isFinite(temperature)) {
    errors.push('temperature must be a number');
  } else if (temperature < LIMITS.TEMP_MIN || temperature > LIMITS.TEMP_MAX) {
    errors.push(`temperature must be between ${LIMITS.TEMP_MIN} and ${LIMITS.TEMP_MAX}`);
  }

  if (typeof humidity !== 'number' || !Number.isFinite(humidity)) {
    errors.push('humidity must be a number');
  } else if (humidity < LIMITS.HUMIDITY_MIN || humidity > LIMITS.HUMIDITY_MAX) {
    errors.push(`humidity must be between ${LIMITS.HUMIDITY_MIN} and ${LIMITS.HUMIDITY_MAX}`);
  }
  return errors;
}

// POST /api/sensor
router.post('/', (req, res, next) => {
  try {
    const errors = validateReading(req.body);
    if (errors.length > 0) {
      return res.status(400).json({ success: false, message: 'Invalid sensor data', errors });
    }
    const { temperature, humidity } = req.body;
    const result = database.insertReading.run(temperature, humidity);
    console.log(`Saved reading #${result.lastInsertRowid}: ${temperature} C, ${humidity} %`);
    return res.status(201).json({
      success: true,
      message: 'Sensor data saved successfully',
      id: Number(result.lastInsertRowid),
    });
  } catch (err) {
    return next(err);
  }
});

// GET /api/sensor/latest
router.get('/latest', (req, res, next) => {
  try {
    const row = database.getLatest.get();
    if (!row) {
      return res.json({ success: true, message: 'No readings stored yet', data: null });
    }
    return res.json({ success: true, data: row });
  } catch (err) {
    return next(err);
  }
});

// GET /api/sensor/history?limit=50
router.get('/history', (req, res, next) => {
  try {
    let limit = DEFAULT_HISTORY_LIMIT;
    if (req.query.limit !== undefined) {
      const requested = Number(req.query.limit);
      if (!Number.isInteger(requested) || requested < 1) {
        return res.status(400).json({
          success: false,
          message: 'limit must be a whole number of 1 or more',
        });
      }
      limit = Math.min(requested, MAX_HISTORY_LIMIT);
    }
    const rows = database.getHistory.all(limit);
    return res.json({ success: true, count: rows.length, data: rows });
  } catch (err) {
    return next(err);
  }
});

module.exports = router;
