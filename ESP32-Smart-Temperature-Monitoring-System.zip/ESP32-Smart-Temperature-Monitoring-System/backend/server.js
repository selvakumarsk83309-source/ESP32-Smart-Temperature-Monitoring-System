/**
 * server.js
 * Starts the Express web server.
 *  - Serves the dashboard from ../frontend  (http://localhost:3000/)
 *  - Exposes the REST API under /api
 */
require('dotenv').config();

const path = require('path');
const express = require('express');
const cors = require('cors');

const database = require('./database'); // opens the DB and creates the table
const sensorRoutes = require('./routes/sensorRoutes');

const app = express();
const PORT = Number(process.env.PORT) || 3000;

// Middleware
app.use(cors());                          // allow browsers/other origins to call the API
app.use(express.json({ limit: '10kb' }));  // parse JSON request bodies

// Simple request log so you can watch the ESP32 requests arrive.
app.use((req, res, next) => {
  console.log(`${new Date().toISOString()}  ${req.method} ${req.originalUrl}`);
  next();
});

// GET /api/health - used to check that the backend is alive
app.get('/api/health', (req, res, next) => {
  try {
    const { total } = database.countReadings.get();
    res.json({
      success: true,
      status: 'ok',
      message: 'ESP32 Smart Temperature Monitoring System backend is running',
      uptime_seconds: Math.round(process.uptime()),
      total_readings: total,
      timestamp: new Date().toISOString(),
    });
  } catch (err) {
    next(err);
  }
});

// Sensor API
app.use('/api/sensor', sensorRoutes);

// Unknown /api URL -> JSON 404
app.use('/api', (req, res) => {
  res.status(404).json({ success: false, message: `API route not found: ${req.method} ${req.originalUrl}` });
});

// Dashboard: GET / serves frontend/index.html
app.use(express.static(path.join(__dirname, '..', 'frontend')));

// Error handler (bad JSON, database problems, ...)
app.use((err, req, res, next) => {
  if (err.type === 'entity.parse.failed' || err instanceof SyntaxError) {
    return res.status(400).json({ success: false, message: 'Invalid JSON in request body' });
  }
  console.error('Server error:', err);
  return res.status(500).json({ success: false, message: 'Internal server error' });
});

// 0.0.0.0 = accept connections from other devices on the network (the ESP32).
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running on http://localhost:${PORT}`);
  console.log(`Database file: ${database.DB_PATH}`);
  console.log('ESP32 should post to: http://YOUR_COMPUTER_IP:' + PORT + '/api/sensor');
});
