/**
 * database.js
 * Opens the SQLite database, creates the table automatically and exposes
 * small prepared statements used by the API routes.
 */
const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');

// Where the database file lives. Can be changed with DB_PATH in .env
const DB_PATH = process.env.DB_PATH
  ? path.resolve(process.env.DB_PATH)
  : path.join(__dirname, 'data', 'sensor.db');

// Make sure the folder exists (SQLite creates the file but not the folder).
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

const db = new Database(DB_PATH);

// Fallback copy of database/schema.sql, used only if that file cannot be read.
const FALLBACK_SCHEMA = `
  CREATE TABLE IF NOT EXISTS sensor_readings (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    temperature REAL    NOT NULL,
    humidity    REAL    NOT NULL,
    created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
  );
  CREATE INDEX IF NOT EXISTS idx_sensor_readings_created_at
    ON sensor_readings (created_at);
`;

let schemaSql = FALLBACK_SCHEMA;
try {
  schemaSql = fs.readFileSync(path.join(__dirname, '..', 'database', 'schema.sql'), 'utf8');
} catch (err) {
  console.warn('Could not read database/schema.sql, using built-in schema.');
}
db.exec(schemaSql);

// Prepared statements (safe from SQL injection because values are parameters).
const insertReading = db.prepare(
  'INSERT INTO sensor_readings (temperature, humidity) VALUES (?, ?)'
);
const getLatest = db.prepare(
  'SELECT id, temperature, humidity, created_at FROM sensor_readings ORDER BY id DESC LIMIT 1'
);
const getHistory = db.prepare(
  'SELECT id, temperature, humidity, created_at FROM sensor_readings ORDER BY id DESC LIMIT ?'
);
const countReadings = db.prepare('SELECT COUNT(*) AS total FROM sensor_readings');

module.exports = { db, DB_PATH, insertReading, getLatest, getHistory, countReadings };
