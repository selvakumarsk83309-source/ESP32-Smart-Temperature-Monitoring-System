/**
 * script.js - dashboard logic for the ESP32 Smart Temperature Monitoring System.
 *
 * Flow:  Browser --GET /api/sensor/latest--> Express --> SQLite
 *        Browser --GET /api/sensor/history--> Express --> SQLite
 * Then the cards, charts and table are updated. This repeats automatically.
 */
"use strict";

/* ===================== SETTINGS (easy to change) ===================== */
const CONFIG = {
  // Empty string = same server that served this page (http://localhost:3000).
  // Only change this if you open the dashboard from a different place,
  // e.g. "http://192.168.x.x:3000".
  API_BASE: "",

  REFRESH_INTERVAL_MS: 5000,   // how often to fetch new data (5000 = 5 seconds)
  REQUEST_TIMEOUT_MS: 4000,    // give up on a request after this long
  HISTORY_LIMIT: 50,           // readings used for the charts
  TABLE_ROWS: 15,              // rows shown in the table
  OFFLINE_AFTER_SECONDS: 30,   // no new reading for this long = ESP32 offline

  // Temperature thresholds in °C (demo values only - NOT safety limits)
  TEMP: { coolBelow: 20, warmFrom: 30, highFrom: 35, scaleMin: 0, scaleMax: 50 },

  // Humidity thresholds in % (demo values only)
  HUMIDITY: { dryBelow: 30, humidFrom: 60 },
};
/* ===================================================================== */

const $ = (id) => document.getElementById(id);

const state = {
  backendOk: null,       // true / false / null (unknown yet)
  lastReadingTime: null, // Date of the newest reading, or null
  hasData: false,
  tempChart: null,
  humidityChart: null,
};

/* ---------- Status helpers ---------- */

function getTemperatureStatus(t) {
  if (t < CONFIG.TEMP.coolBelow) return { label: "Cool", key: "cool" };
  if (t < CONFIG.TEMP.warmFrom) return { label: "Normal", key: "normal" };
  if (t < CONFIG.TEMP.highFrom) return { label: "Warm", key: "warm" };
  return { label: "High", key: "high" };
}

function getHumidityStatus(h) {
  if (h < CONFIG.HUMIDITY.dryBelow) return { label: "Dry", key: "dry" };
  if (h <= CONFIG.HUMIDITY.humidFrom) return { label: "Comfortable", key: "comfortable" };
  return { label: "Humid", key: "humid" };
}

function setPill(id, text, level) {
  const el = $(id);
  el.textContent = text;
  el.className = "pill " + level;
}

function setBadge(id, text, key) {
  const el = $(id);
  el.textContent = text;
  el.className = "badge badge-" + key;
}

/* ---------- Time helpers ---------- */

// The database stores UTC like "2026-01-31 14:05:09". Convert to a Date.
function parseDbTime(text) {
  return new Date(text.replace(" ", "T") + "Z");
}

function plural(n, word) {
  return n + " " + word + (n === 1 ? "" : "s");
}

function timeAgo(date) {
  const seconds = Math.max(0, Math.round((Date.now() - date.getTime()) / 1000));
  if (seconds < 60) return plural(seconds, "second") + " ago";
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return plural(minutes, "minute") + " ago";
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return plural(hours, "hour") + " ago";
  return plural(Math.floor(hours / 24), "day") + " ago";
}

/* ---------- Network ---------- */

async function fetchJson(path) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), CONFIG.REQUEST_TIMEOUT_MS);
  try {
    const response = await fetch(CONFIG.API_BASE + path, { signal: controller.signal, cache: "no-store" });
    if (!response.ok) {
      const error = new Error("The server answered with HTTP " + response.status);
      error.isHttpError = true;
      throw error;
    }
    return await response.json();
  } finally {
    clearTimeout(timer);
  }
}

/* ---------- Rendering ---------- */

function showError(message) {
  const banner = $("error-banner");
  banner.textContent = message;
  banner.hidden = false;
}

function hideError() {
  $("error-banner").hidden = true;
}

function buildScale() {
  const t = CONFIG.TEMP;
  const range = t.scaleMax - t.scaleMin;
  const parts = [
    ["band-cool", t.coolBelow - t.scaleMin],
    ["band-normal", t.warmFrom - t.coolBelow],
    ["band-warm", t.highFrom - t.warmFrom],
    ["band-high", t.scaleMax - t.highFrom],
  ];
  const container = $("scale-bands");
  container.textContent = "";
  parts.forEach(([className, size]) => {
    const band = document.createElement("span");
    band.className = className;
    band.style.width = (size / range) * 100 + "%";
    container.appendChild(band);
  });
}

function renderLatest(reading) {
  const temp = Number(reading.temperature);
  const humidity = Number(reading.humidity);

  $("temp-value").textContent = temp.toFixed(1);
  $("humidity-value").textContent = humidity.toFixed(1);

  const tempStatus = getTemperatureStatus(temp);
  const humStatus = getHumidityStatus(humidity);
  setBadge("temp-status", tempStatus.label, tempStatus.key);
  setBadge("humidity-status", humStatus.label, humStatus.key);

  // Move the marker on the temperature scale (kept inside 0-100 %).
  const t = CONFIG.TEMP;
  const percent = Math.min(100, Math.max(0, ((temp - t.scaleMin) / (t.scaleMax - t.scaleMin)) * 100));
  const marker = $("scale-marker");
  marker.style.left = percent + "%";
  marker.hidden = false;

  state.lastReadingTime = parseDbTime(reading.created_at);
  state.hasData = true;
  $("updated-at").textContent = state.lastReadingTime.toLocaleString();
}

function renderEmpty() {
  state.hasData = false;
  state.lastReadingTime = null;
  $("temp-value").textContent = "--";
  $("humidity-value").textContent = "--";
  setBadge("temp-status", "--", "none");
  setBadge("humidity-status", "--", "none");
  $("scale-marker").hidden = true;
  $("updated-at").innerHTML = "&nbsp;";
  clearCharts("No readings yet. Power on the ESP32 or send a test reading.");
  renderTable([], "No readings yet. Power on the ESP32 or send a test reading (see README).");
}

function renderTable(rows, emptyMessage) {
  const body = $("readings-body");
  body.textContent = "";
  if (rows.length === 0) {
    const tr = document.createElement("tr");
    const td = document.createElement("td");
    td.colSpan = 5;
    td.className = "empty";
    td.textContent = emptyMessage || "No readings available.";
    tr.appendChild(td);
    body.appendChild(tr);
    return;
  }
  rows.slice(0, CONFIG.TABLE_ROWS).forEach((row) => {
    const when = parseDbTime(row.created_at);
    const cells = [
      row.id,
      Number(row.temperature).toFixed(1) + " °C",
      Number(row.humidity).toFixed(1) + " %",
      when.toLocaleDateString(),
      when.toLocaleTimeString(),
    ];
    const tr = document.createElement("tr");
    cells.forEach((value) => {
      const td = document.createElement("td");
      td.textContent = value;
      tr.appendChild(td);
    });
    body.appendChild(tr);
  });
}

/* ---------- Charts ---------- */

function createChart(canvasId, label, color, yTitle) {
  return new Chart($(canvasId), {
    type: "line",
    data: {
      labels: [],
      datasets: [{
        label,
        data: [],
        borderColor: color,
        backgroundColor: color + "26",
        fill: true,
        tension: 0.3,
        pointRadius: 2,
        borderWidth: 2,
      }],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      animation: false,
      plugins: { legend: { display: false } },
      scales: {
        x: {
          title: { display: true, text: "Time", color: "#8a9bb3" },
          ticks: { color: "#8a9bb3", maxTicksLimit: 6, maxRotation: 0 },
          grid: { color: "rgba(138,155,179,0.12)" },
        },
        y: {
          title: { display: true, text: yTitle, color: "#8a9bb3" },
          ticks: { color: "#8a9bb3" },
          grid: { color: "rgba(138,155,179,0.12)" },
        },
      },
    },
  });
}

function initCharts() {
  if (typeof Chart === "undefined") {
    ["temp-chart-note", "humidity-chart-note"].forEach((id) => {
      const note = $(id);
      note.textContent = "Charts could not load. Chart.js comes from the internet, so check your connection and reload.";
      note.hidden = false;
    });
    return;
  }
  state.tempChart = createChart("temp-chart", "Temperature (°C)", "#ffb454", "Temperature (°C)");
  state.humidityChart = createChart("humidity-chart", "Humidity (%)", "#4cc9f0", "Humidity (%)");
}

function renderCharts(rows) {
  if (!state.tempChart) return;
  // The API returns newest first; charts need oldest first.
  const ordered = rows.slice().reverse();
  const labels = ordered.map((r) => parseDbTime(r.created_at).toLocaleTimeString());
  state.tempChart.data.labels = labels;
  state.tempChart.data.datasets[0].data = ordered.map((r) => Number(r.temperature));
  state.humidityChart.data.labels = labels;
  state.humidityChart.data.datasets[0].data = ordered.map((r) => Number(r.humidity));
  state.tempChart.update("none");
  state.humidityChart.update("none");
  ["temp-chart-note", "humidity-chart-note"].forEach((id) => { $(id).hidden = true; });
}

function clearCharts(message) {
  if (state.tempChart) {
    [state.tempChart, state.humidityChart].forEach((chart) => {
      chart.data.labels = [];
      chart.data.datasets[0].data = [];
      chart.update("none");
    });
  }
  ["temp-chart-note", "humidity-chart-note"].forEach((id) => {
    $(id).textContent = message;
    $(id).hidden = false;
  });
}

/* ---------- Freshness (runs every second) ---------- */

function renderFreshness() {
  if (state.backendOk !== true) {
    // Backend unreachable or errored: we cannot know the ESP32 state.
    if (state.backendOk === false) {
      setPill("esp32-status", "Unknown", "unknown");
      setPill("sensor-status", "Unknown", "unknown");
      $("updated-ago").textContent = state.lastReadingTime
        ? "Last data " + timeAgo(state.lastReadingTime)
        : "Unavailable";
    }
    return;
  }

  if (!state.hasData) {
    setPill("esp32-status", "Waiting for data", "unknown");
    setPill("sensor-status", "No data", "unknown");
    $("updated-ago").textContent = "No data yet";
    return;
  }

  const ageSeconds = (Date.now() - state.lastReadingTime.getTime()) / 1000;
  $("updated-ago").textContent = "Updated " + timeAgo(state.lastReadingTime);
  if (ageSeconds <= CONFIG.OFFLINE_AFTER_SECONDS) {
    setPill("esp32-status", "Online", "ok");
    setPill("sensor-status", "Connected", "ok");
  } else {
    // The ESP32 only sends valid readings, so a stale feed means the ESP32,
    // its Wi-Fi or its sensor stopped delivering data.
    setPill("esp32-status", "Offline", "bad");
    setPill("sensor-status", "Error", "bad");
  }
}

/* ---------- Main refresh ---------- */

async function refreshData() {
  try {
    const [latest, history] = await Promise.all([
      fetchJson("/api/sensor/latest"),
      fetchJson("/api/sensor/history?limit=" + CONFIG.HISTORY_LIMIT),
    ]);
    state.backendOk = true;
    setPill("backend-status", "Online", "ok");
    hideError();

    const rows = Array.isArray(history.data) ? history.data : [];
    if (!latest.data) {
      renderEmpty();
    } else {
      renderLatest(latest.data);
      renderCharts(rows);
      renderTable(rows);
    }
  } catch (error) {
    state.backendOk = false;
    if (error.isHttpError) {
      setPill("backend-status", "Error", "bad");
      showError("The backend answered with an error (" + error.message + "). Check the backend terminal for details.");
    } else {
      setPill("backend-status", "Offline", "bad");
      showError("Cannot reach the backend. Make sure it is running (cd backend, then npm start) and reload this page.");
    }
  } finally {
    $("loading").classList.add("done");
    renderFreshness();
  }
}

document.addEventListener("DOMContentLoaded", () => {
  buildScale();
  initCharts();
  refreshData();
  setInterval(refreshData, CONFIG.REFRESH_INTERVAL_MS);
  setInterval(renderFreshness, 1000);
});
