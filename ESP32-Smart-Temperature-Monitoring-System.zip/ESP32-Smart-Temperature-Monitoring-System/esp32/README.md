# ESP32 Firmware

File: `temperature_monitor.ino`

The ESP32 reads the DHT11 (temperature and humidity) and sends the values to the backend as JSON using HTTP POST every 10 seconds.

## Wiring

| DHT11 pin | ESP32 pin |
|---|---|
| VCC / + | 3V3 |
| DATA / S / OUT | GPIO 4 |
| GND / - | GND |

Details and a bare-sensor (4-pin) pull-up resistor note are in [`../hardware/wiring.md`](../hardware/wiring.md).

## Arduino IDE setup

1. Install **Arduino IDE 2.x** from <https://www.arduino.cc/en/software>.
2. **File → Preferences → Additional boards manager URLs**, add:
   `https://espressif.github.io/arduino-esp32/package_esp32_index.json`
3. **Tools → Board → Boards Manager**, search `esp32`, install **esp32 by Espressif Systems**.
4. **Sketch → Include Library → Manage Libraries**, install **DHT sensor library** (Adafruit) and **Adafruit Unified Sensor**.
5. **File → Open**, choose `esp32/temperature_monitor.ino`. (Arduino may offer to move it into a folder named `temperature_monitor`; click OK.)
6. **Tools → Board → esp32 → ESP32 Dev Module**.
7. **Tools → Port → COMx** (find yours in Device Manager → Ports).

## Configure (on your own computer only)

Edit these three lines:

```cpp
const char* WIFI_SSID     = "YOUR_WIFI_NAME";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";
const char* SERVER_URL    = "http://YOUR_COMPUTER_IP:3000/api/sensor";
```

- Find `YOUR_COMPUTER_IP`: open Command Prompt, run `ipconfig`, copy **IPv4 Address** of your Wi-Fi adapter.
- Never use `localhost` here: on the ESP32 it means the ESP32 itself.
- The ESP32 and the laptop must be on the same 2.4 GHz Wi-Fi network.
- **Change the values back to the placeholders before you commit to GitHub.**

## Upload and test

1. Start the backend first (`cd backend`, `npm start`).
2. Click **Upload**. If it hangs at "Connecting......", hold the **BOOT** button on the ESP32.
3. **Tools → Serial Monitor**, baud **115200**.

Expected output (your values will differ):

```
Connecting to WiFi...
WiFi connected
IP address: <your ESP32 IP>
Temperature: XX.X °C
Humidity: XX.X %
Sending data...
Server response: 201
```

## Behaviour

- Reconnects automatically if Wi-Fi drops.
- Ignores `NaN` or out-of-range sensor values (they are never sent).
- Gives up on the server after 5 seconds, so it never freezes.
- Settings (interval, timeouts, limits) are constants at the top of the file.
