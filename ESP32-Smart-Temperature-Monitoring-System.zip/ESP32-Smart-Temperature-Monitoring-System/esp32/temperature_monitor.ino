/*
 * ESP32 Smart Temperature Monitoring System
 * -----------------------------------------
 * Reads temperature and humidity from a DHT11 sensor and sends them to the
 * Node.js backend using an HTTP POST request every SEND_INTERVAL_MS.
 *
 * Wiring (ESP32 DevKit V1, 38-pin):
 *   DHT11 VCC  -> 3V3
 *   DHT11 DATA -> GPIO 4
 *   DHT11 GND  -> GND
 *
 * Libraries (Arduino IDE -> Library Manager):
 *   - "DHT sensor library" by Adafruit
 *   - "Adafruit Unified Sensor" by Adafruit
 *   WiFi.h and HTTPClient.h come with the ESP32 board package.
 *
 * Serial Monitor baud rate: 115200
 *
 * IMPORTANT: Replace the three YOUR_... values below ON YOUR OWN COMPUTER ONLY.
 * Never upload your real Wi-Fi password to GitHub.
 */

#include <WiFi.h>
#include <HTTPClient.h>
#include <DHT.h>

// ===================== SETTINGS YOU MUST CHANGE =====================
const char* WIFI_SSID     = "YOUR_WIFI_NAME";      // your 2.4 GHz Wi-Fi name
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";  // your Wi-Fi password

// Use your laptop's IPv4 address (run "ipconfig" on Windows). NOT "localhost":
// on the ESP32, "localhost" means the ESP32 itself, not your laptop.
const char* SERVER_URL = "http://YOUR_COMPUTER_IP:3000/api/sensor";
// ====================================================================

// ---------- Sensor settings ----------
#define DHT_PIN  4          // DHT11 DATA pin is connected to GPIO 4
#define DHT_TYPE DHT11
DHT dht(DHT_PIN, DHT_TYPE);

// ---------- Timing settings ----------
const unsigned long SEND_INTERVAL_MS = 10000;   // send a reading every 10 seconds
const unsigned long WIFI_TIMEOUT_MS  = 20000;   // give up one Wi-Fi attempt after 20 s
const int           HTTP_TIMEOUT_MS  = 5000;    // give up on the server after 5 s

// ---------- Sanity limits for readings ----------
const float TEMP_MIN_VALID     = 0.0;
const float TEMP_MAX_VALID     = 60.0;
const float HUMIDITY_MIN_VALID = 0.0;
const float HUMIDITY_MAX_VALID = 100.0;

unsigned long lastSendTime = 0;
bool firstReading = true;

// Connects to Wi-Fi. Returns true on success, false on timeout.
bool connectToWiFi() {
  Serial.println();
  Serial.println("Connecting to WiFi...");
  Serial.print("Network: ");
  Serial.println(WIFI_SSID);

  WiFi.mode(WIFI_STA);
  WiFi.disconnect();
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  unsigned long startTime = millis();
  while (WiFi.status() != WL_CONNECTED) {
    if (millis() - startTime > WIFI_TIMEOUT_MS) {
      Serial.println();
      Serial.println("WiFi connection failed (timeout). Check name, password and 2.4 GHz.");
      return false;
    }
    delay(500);
    Serial.print(".");
  }

  Serial.println();
  Serial.println("WiFi connected");
  Serial.print("IP address: ");
  Serial.println(WiFi.localIP());
  return true;
}

// Reads the DHT11 and checks the values. Returns true if they are usable.
bool readSensor(float &temperature, float &humidity) {
  humidity = dht.readHumidity();
  temperature = dht.readTemperature();   // Celsius

  if (isnan(temperature) || isnan(humidity)) {
    Serial.println("Sensor read failed (NaN). Check wiring: VCC=3V3, DATA=GPIO 4, GND=GND.");
    return false;
  }
  if (temperature < TEMP_MIN_VALID || temperature > TEMP_MAX_VALID ||
      humidity < HUMIDITY_MIN_VALID || humidity > HUMIDITY_MAX_VALID) {
    Serial.println("Sensor values out of range - reading ignored.");
    return false;
  }
  return true;
}

// Sends one reading to the backend. Returns true if the server accepted it.
bool sendReading(float temperature, float humidity) {
  // Build the JSON text, for example {"temperature":27.5,"humidity":60.0}
  char payload[64];
  snprintf(payload, sizeof(payload), "{\"temperature\":%.1f,\"humidity\":%.1f}", temperature, humidity);

  HTTPClient http;
  http.setTimeout(HTTP_TIMEOUT_MS);
  if (!http.begin(SERVER_URL)) {
    Serial.println("Invalid SERVER_URL. Expected http://YOUR_COMPUTER_IP:3000/api/sensor");
    return false;
  }
  http.addHeader("Content-Type", "application/json");

  Serial.println("Sending data...");
  int httpCode = http.POST(payload);

  bool success = false;
  if (httpCode > 0) {
    Serial.print("Server response: ");
    Serial.println(httpCode);
    Serial.println(http.getString());
    success = (httpCode >= 200 && httpCode < 300);
  } else {
    Serial.print("HTTP request failed: ");
    Serial.println(HTTPClient::errorToString(httpCode));
    Serial.println("Check: backend running? correct laptop IP? same Wi-Fi? firewall allows port 3000?");
  }
  http.end();
  return success;
}

void setup() {
  Serial.begin(115200);
  delay(1000);
  Serial.println("ESP32 Smart Temperature Monitoring System");

  dht.begin();
  connectToWiFi();
}

void loop() {
  // 1) Make sure Wi-Fi is still connected; reconnect if it dropped.
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("WiFi lost. Reconnecting...");
    if (!connectToWiFi()) {
      delay(5000);   // wait a little, then try again on the next loop
      return;
    }
  }

  // 2) Only read and send once per SEND_INTERVAL_MS.
  if (!firstReading && millis() - lastSendTime < SEND_INTERVAL_MS) {
    delay(100);
    return;
  }
  firstReading = false;
  lastSendTime = millis();

  // 3) Read the sensor.
  float temperature = 0;
  float humidity = 0;
  if (!readSensor(temperature, humidity)) {
    return;   // try again after the next interval
  }

  Serial.printf("Temperature: %.1f °C\n", temperature);
  Serial.printf("Humidity: %.1f %%\n", humidity);

  // 4) Send it to the backend.
  sendReading(temperature, humidity);
}
