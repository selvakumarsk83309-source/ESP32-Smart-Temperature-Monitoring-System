# API Documentation

Base URL (local): `http://localhost:3000`
From the ESP32: `http://YOUR_COMPUTER_IP:3000`

All API responses are JSON. Timestamps in `created_at` are **UTC** (`YYYY-MM-DD HH:MM:SS`).

## Summary

| Method | URL | Purpose |
|---|---|---|
| GET | `/` | Dashboard (HTML) |
| GET | `/api/health` | Health check |
| POST | `/api/sensor` | Save a reading |
| GET | `/api/sensor/latest` | Newest reading |
| GET | `/api/sensor/history` | Recent readings |

## GET /

- **Purpose:** serves the dashboard (`frontend/index.html`).
- **Request body:** none.
- **Response:** HTML page with status `200`.
- **Errors:** none expected.

```
curl http://localhost:3000/
```

## GET /api/health

- **Purpose:** check that the backend and database are working.
- **Request body:** none.
- **Response `200`:**
```json
{
  "success": true,
  "status": "ok",
  "message": "ESP32 Smart Temperature Monitoring System backend is running",
  "uptime_seconds": 42,
  "total_readings": 3,
  "timestamp": "2026-01-31T10:15:00.000Z"
}
```
- **Errors:** `500` `{ "success": false, "message": "Internal server error" }` if the database fails.

```
curl http://localhost:3000/api/health
```

## POST /api/sensor

- **Purpose:** save one reading (the ESP32 calls this).
- **Headers:** `Content-Type: application/json`
- **Request body:**
```json
{ "temperature": 27.5, "humidity": 62 }
```
Rules: both fields must be numbers; humidity 0 to 100; temperature -40 to 125 (sanity range).

- **Response `201`:**
```json
{ "success": true, "message": "Sensor data saved successfully", "id": 7 }
```
- **Error `400` (invalid data):**
```json
{ "success": false, "message": "Invalid sensor data", "errors": ["humidity must be between 0 and 100"] }
```
- **Error `400` (broken JSON):** `{ "success": false, "message": "Invalid JSON in request body" }`
- **Error `500`:** `{ "success": false, "message": "Internal server error" }`

Command Prompt:
```
curl -X POST http://localhost:3000/api/sensor ^
-H "Content-Type: application/json" ^
-d "{\"temperature\":27.5,\"humidity\":60}"
```
PowerShell:
```powershell
Invoke-RestMethod -Method Post -Uri http://localhost:3000/api/sensor `
  -ContentType "application/json" `
  -Body '{"temperature":27.5,"humidity":60}'
```

## GET /api/sensor/latest

- **Purpose:** newest stored reading (dashboard cards).
- **Request body:** none.
- **Response `200`:**
```json
{
  "success": true,
  "data": { "id": 7, "temperature": 27.5, "humidity": 62, "created_at": "2026-01-31 10:15:00" }
}
```
- **Response `200` when the database is empty:**
```json
{ "success": true, "message": "No readings stored yet", "data": null }
```
- **Errors:** `500` on a database failure.

```
curl http://localhost:3000/api/sensor/latest
```

## GET /api/sensor/history

- **Purpose:** recent readings, newest first (charts and table).
- **Query parameter:** `limit` (optional, whole number, default `50`, maximum `500`).
- **Response `200`:**
```json
{
  "success": true,
  "count": 2,
  "data": [
    { "id": 7, "temperature": 27.5, "humidity": 62, "created_at": "2026-01-31 10:15:00" },
    { "id": 6, "temperature": 27.4, "humidity": 61, "created_at": "2026-01-31 10:14:50" }
  ]
}
```
- **Error `400`:** `limit` is not a whole number of 1 or more.
```json
{ "success": false, "message": "limit must be a whole number of 1 or more" }
```
- **Error `500`:** database failure.

```
curl "http://localhost:3000/api/sensor/history?limit=10"
```

## Unknown API route

Any other `/api/...` URL returns `404`:
```json
{ "success": false, "message": "API route not found: GET /api/nope" }
```
