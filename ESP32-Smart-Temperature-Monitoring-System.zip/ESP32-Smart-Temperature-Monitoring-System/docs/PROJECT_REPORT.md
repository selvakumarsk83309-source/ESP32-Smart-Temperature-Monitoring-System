# Project Report: ESP32 Smart Temperature Monitoring System

**Author:** [Your Name]  
**Category:** IoT & Embedded Systems  
**Task:** Connect a Temperature Sensor

> **Honesty note:** the tables below separate what is *implemented in the code* from what has been *tested*. Test results must be filled in by the author after running each test. Nothing here claims a test was done unless the author records it.

## 1. Title
ESP32 Smart Temperature Monitoring System

## 2. Abstract
This project builds a complete local IoT system. A DHT11 sensor connected to an ESP32 measures temperature and humidity. The ESP32 sends the readings over Wi-Fi to a Node.js and Express REST API, which validates and stores them in an SQLite database. A responsive web dashboard shows current values, status, history charts and recent readings, and refreshes automatically. The system needs no cloud service and runs on a normal Windows 11 laptop.

## 3. Introduction
IoT systems connect physical sensors to software. Temperature and humidity monitoring is a common first IoT application. This project covers the full chain: sensor, microcontroller, network, backend, database and user interface.

## 4. Problem Statement
Manual reading of temperature and humidity is slow and leaves no history. A low-cost automated system is needed that measures, stores and displays environmental readings in near real time.

## 5. Objectives
- Interface a DHT11 sensor with an ESP32.
- Send readings over Wi-Fi using HTTP.
- Validate and store readings in a database.
- Provide REST API endpoints.
- Display current and historical data on a responsive dashboard.
- Handle errors (sensor failure, Wi-Fi loss, backend offline).

## 6. Existing System
Handheld thermometers or standalone displays show only the current value, store no history and cannot be viewed remotely. Commercial cloud IoT platforms are powerful but add accounts, cost and complexity for a beginner.

## 7. Proposed System
A local system: ESP32 → Wi-Fi → Node.js/Express → SQLite → browser dashboard. It stores every valid reading and shows trends, with no paid service.

## 8. Hardware Requirements
ESP32 DevKit V1 (38-pin), DHT11 sensor or module, breadboard, jumper wires, USB data cable, laptop. A 10 kΩ pull-up resistor is needed only for a bare 4-pin DHT11. A multimeter is optional.

## 9. Software Requirements
Windows 11, Arduino IDE 2.x (ESP32 board package, Adafruit DHT libraries), Node.js LTS with npm, VS Code, Git/GitHub, a web browser.

## 10. System Architecture
```
DHT11 → ESP32 → Wi-Fi → Node.js + Express → REST API → SQLite → Frontend dashboard
```

## 11. Circuit Description
DHT11 VCC → ESP32 3V3, DHT11 DATA → GPIO 4, DHT11 GND → GND. GPIO 4 is a general-purpose pin without special boot behaviour. A module has a built-in pull-up resistor; a bare sensor needs 10 kΩ between VCC and DATA. See `hardware/wiring.md` and `hardware/circuit-diagram.svg`.

## 12. Working Principle
1. The ESP32 connects to Wi-Fi.
2. Every 10 seconds it reads the DHT11 and checks the values.
3. It sends `{"temperature":..,"humidity":..}` to `/api/sensor` using HTTP POST.
4. The backend validates the data and inserts a row into `sensor_readings`.
5. The dashboard requests the latest and history data every 5 seconds and updates the page.

## 13. ESP32 Programming
`esp32/temperature_monitor.ino` uses `WiFi.h`, `HTTPClient.h` and the Adafruit `DHT.h`. Features: Wi-Fi connection with timeout, automatic reconnect, NaN and range checks, JSON payload building, HTTP timeout, Serial Monitor logging at 115200 baud. Wi-Fi name, password and server URL are placeholders.

## 14. Backend Development
Node.js with Express. `server.js` sets up middleware (CORS, JSON parser, request logging), the health route, the sensor routes, a JSON 404 for unknown API paths, static hosting of the dashboard and an error handler. `routes/sensorRoutes.js` holds validation and the three sensor endpoints. `database.js` opens SQLite and runs the schema.

## 15. Database Design
Table `sensor_readings`: `id` (INTEGER PRIMARY KEY AUTOINCREMENT), `temperature` (REAL), `humidity` (REAL), `created_at` (TEXT, default `datetime('now')`, UTC). Created automatically from `database/schema.sql` at startup. Queries use prepared statements.

## 16. Frontend Development
Plain HTML, CSS and JavaScript with Chart.js from a CDN. The page shows temperature, humidity, status badges, last update time, backend/ESP32/sensor status, two line charts and a recent readings table. It refreshes every 5 seconds (`CONFIG.REFRESH_INTERVAL_MS`), shows loading, empty and error states, and adapts to desktop, tablet and mobile widths.

Temperature thresholds (dashboard demonstration only, not safety limits): below 20 °C Cool, 20 to 29.9 °C Normal, 30 to 34.9 °C Warm, 35 °C and above High. Humidity: below 30 % Dry, 30 to 60 % Comfortable, above 60 % Humid.

## 17. API Design
| Method | URL | Purpose |
|---|---|---|
| GET | `/` | Dashboard |
| GET | `/api/health` | Health check |
| POST | `/api/sensor` | Save reading (201, or 400 if invalid) |
| GET | `/api/sensor/latest` | Newest reading |
| GET | `/api/sensor/history` | Recent readings (`limit`, default 50, max 500) |

Full details: `docs/API_DOCUMENTATION.md`.

## 18. Testing
Testing follows this order: software installation, Arduino/ESP32 setup, USB port, wiring, basic sensor sketch, Wi-Fi, laptop IP, backend start, manual POST, database check, dashboard, ESP32 to backend, end-to-end, auto refresh, backend failure, Wi-Fi failure, invalid data, responsive layout and GitHub safety check.

### Implementation vs testing status
| Item | Implemented in code | Tested by author |
|---|---|---|
| ESP32 Wi-Fi + reconnect | Yes | To be tested |
| DHT11 reading + validation | Yes | To be tested |
| HTTP POST from ESP32 | Yes | To be tested |
| Backend API + validation | Yes | To be tested |
| SQLite storage | Yes | To be tested |
| Dashboard cards, charts, table | Yes | To be tested |
| Error / offline / empty states | Yes | To be tested |
| Responsive layout | Yes | To be tested |
| OLED, MQTT, alerts, auth, cloud | No (future work) | Not applicable |

## 19. Test Cases
| ID | Test | Input / Action | Expected Result | Actual Result | Status |
|---|---|---|---|---|---|
| TC1 | ESP32 Wi-Fi connection | Upload sketch with correct credentials | Serial shows "WiFi connected" and an IP | User verification required | To be tested |
| TC2 | DHT11 temperature | Open Serial Monitor | A plausible temperature in °C is printed | User verification required | To be tested |
| TC3 | DHT11 humidity | Open Serial Monitor | A plausible humidity in % is printed | User verification required | To be tested |
| TC4 | POST sensor data | curl POST with valid JSON | HTTP 201, success JSON | User verification required | To be tested |
| TC5 | Invalid humidity | POST humidity 150 | HTTP 400, nothing stored | User verification required | To be tested |
| TC6 | Database insertion | POST then open `/api/sensor/history` | New row present | User verification required | To be tested |
| TC7 | Dashboard data loading | Open `http://localhost:3000/` | Cards, charts and table show data | User verification required | To be tested |
| TC8 | Backend unavailable | Stop backend while dashboard is open | Offline status and error banner | User verification required | To be tested |
| TC9 | Mobile responsive layout | Browser at about 375 px width | No sideways scrolling, readable cards | User verification required | To be tested |
| TC10 | Wi-Fi failure | Turn Wi-Fi off, then on | ESP32 does not crash and reconnects | User verification required | To be tested |
| TC11 | End-to-end | Run ESP32 + backend + dashboard | Dashboard matches Serial values | User verification required | To be tested |

## 20. Results
*To be completed by the author after testing.* Suggested content: screenshots of the dashboard and Serial Monitor, a short description of observed behaviour, and the completed test table. Do not record results that were not observed.

## 21. Advantages
Low cost, runs locally, beginner friendly, simple stack, full data history, clear error handling, easy to extend.

## 22. Limitations
- DHT11 accuracy is about ±2 °C and ±5 % humidity, with a 0 to 50 °C range.
- Readings during Wi-Fi or backend outages are not buffered.
- HTTP without authentication or encryption; suitable only for a trusted local network.
- The laptop IP can change, so the ESP32 code may need updating.
- One device, SQLite and no data cleanup or export.
- The ESP32 status is inferred from data freshness.

## 23. Future Enhancements
OLED display, Blynk or cloud integration, MQTT, mobile app, email alerts, threshold alerts, multiple ESP32 devices, authentication, cloud database, OTA updates, data export, more accurate sensors (DHT22 / BME280).

## 24. Conclusion
The project demonstrates an end-to-end IoT pipeline from sensor to dashboard using beginner-friendly, free tools. After the author completes the test table, it can serve as a documented, working internship submission.

## 25. Learning Outcomes
- Sensor interfacing and GPIO usage
- ESP32 Wi-Fi and HTTP programming
- REST API design and input validation
- SQLite database design from Node.js
- Frontend development with fetch and Chart.js
- Debugging network issues (IP addressing, firewall, localhost)
- Documentation and GitHub project organisation
