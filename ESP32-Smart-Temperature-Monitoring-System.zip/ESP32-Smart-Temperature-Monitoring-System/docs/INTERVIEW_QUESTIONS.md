# Interview Questions and Answers

Simple answers you can explain in your own words.

**1. Why did you use ESP32?**
It has built-in Wi-Fi, enough processing power, many GPIO pins, works with Arduino IDE, and is cheap. A normal Arduino Uno would need an extra Wi-Fi module.

**2. Why DHT11?**
It is low cost, easy to wire (one data pin) and has a ready Arduino library. It is good for learning and room-level monitoring.

**3. How does the ESP32 communicate with the server?**
It joins the Wi-Fi network, then sends an HTTP POST request with JSON data to the laptop's IP address on port 3000.

**4. Why HTTP?**
It is simple, built into the ESP32 libraries, easy to test with curl or a browser, and fine for one reading every 10 seconds on a local network.

**5. What is a REST API?**
A set of URLs where each URL does one job and uses HTTP methods: GET reads data, POST sends data. Responses are usually JSON. Example: `POST /api/sensor` saves a reading.

**6. Why SQLite?**
It stores everything in one file and needs no server or installation, so the project runs on any laptop. It is enough for one device.

**7. What happens if Wi-Fi disconnects?**
The code checks the Wi-Fi status in every loop. If it is lost, it prints a message and reconnects. Readings during the outage are not stored (a limitation). The dashboard shows the ESP32 as Offline when no new data arrives for 30 seconds.

**8. What is GPIO?**
General Purpose Input/Output: pins on the microcontroller that the program can use as input or output. The DHT11 DATA wire is connected to GPIO 4.

**9. How does the DHT11 work?**
It contains a humidity-sensing element and a thermistor. A small chip converts them to a digital signal and sends 40 bits (humidity, temperature and a checksum) on one data wire when the ESP32 requests a reading. The Adafruit library handles this timing.

**10. Why can't the ESP32 use localhost?**
`localhost` always means "this same device". On the ESP32 it points to the ESP32, not the laptop. So we use the laptop's IPv4 address from `ipconfig`.

**11. What is JSON?**
A text format for data made of names and values, such as `{"temperature":27.5,"humidity":60}`. Both the ESP32 and JavaScript understand it easily.

**12. How does the database store readings?**
In the table `sensor_readings` with columns `id`, `temperature`, `humidity` and `created_at`. Each valid POST adds one row, and `created_at` is filled in automatically with the UTC time.

**13. How does the frontend receive data?**
JavaScript uses `fetch()` to call `/api/sensor/latest` and `/api/sensor/history` every 5 seconds, then updates the cards, charts and table.

**14. How did you handle errors?**
ESP32: ignores `NaN` and out-of-range values, uses timeouts, reconnects Wi-Fi. Backend: validates input and returns 400 for bad data, 500 for server errors, and a JSON 404 for unknown API routes. Frontend: shows an error banner and Offline/Unknown states, plus empty states.

**15. What are the limitations of DHT11?**
Accuracy about ±2 °C and ±5 % humidity, range about 0 to 50 °C and 20 to 90 %, slow (about one reading per second at most), and no negative temperatures.

**16. What would you improve?**
Add authentication, a better sensor (DHT22 or BME280), buffering readings during Wi-Fi outages, alerts, and a cloud deployment.

**17. How could MQTT be used?**
The ESP32 would publish readings to an MQTT broker (for example Mosquitto) on a topic like `home/room1/temperature`, and the backend would subscribe and store them. MQTT is lighter than HTTP and better for many devices.

**18. How could this become a cloud IoT project?**
Deploy the backend to a cloud host, use HTTPS, replace SQLite with a cloud database, and give each device its own credentials.

**19. How could authentication be added?**
Give the ESP32 a secret API key sent in a header (for example `x-api-key`), and check it in Express middleware. For the dashboard, add a login with sessions or tokens. Use HTTPS so keys are not readable on the network.

**20. Explain the complete architecture.**
DHT11 measures, ESP32 reads and connects to Wi-Fi, sends JSON via HTTP POST to the Express API, the API validates and saves it in SQLite, and the browser dashboard fetches the data through GET endpoints and shows cards, charts and a table.

**21. Why did you validate data on both the ESP32 and the backend?**
The ESP32 avoids sending bad sensor readings. The backend must never trust incoming data, because anyone on the network could send a request.

**22. Why is a pull-up resistor needed on a bare DHT11?**
The data line is open-drain style: the sensor can pull it low but not drive it high. The resistor holds the line high when idle. Modules already have one.

**23. Why does the dashboard convert times?**
SQLite stores UTC. The browser converts it to the user's local time for display.

**24. How did you keep your Wi-Fi password safe?**
The repository only has placeholders (`YOUR_WIFI_NAME`, `YOUR_WIFI_PASSWORD`). I edit the real values only on my computer and check the project for secrets before pushing.
