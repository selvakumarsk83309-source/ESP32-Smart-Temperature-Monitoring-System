# Troubleshooting

Format: **Problem → Cause → Solution**.

## 1. ESP32 not detected
- **Cause:** charge-only USB cable, missing driver, or a bad USB port.
- **Solution:** use a data cable; try another port; check Device Manager → Ports (COM & LPT). If nothing appears, install the CP210x or CH340 driver (the chip near the USB port tells you which).

## 2. DHT11 returning NaN
- **Cause:** wrong wiring, DATA not on GPIO 4, missing pull-up on a bare sensor, or reading too fast.
- **Solution:** recheck VCC → 3V3, DATA → GPIO 4, GND → GND. For a bare 4-pin sensor add a 10 kΩ resistor between VCC and DATA. Keep at least 2 seconds between reads (the sketch uses 10 s). Unplug and replug the USB.

## 3. Wi-Fi not connecting
- **Cause:** wrong name/password (case-sensitive), a 5 GHz-only network, or weak signal.
- **Solution:** fix `WIFI_SSID` and `WIFI_PASSWORD`; use a 2.4 GHz network; move closer. A phone hotspot (2.4 GHz) is a good test.

## 4. ESP32 cannot reach backend
- **Cause:** backend not running, wrong IP, firewall, different Wi-Fi, or client isolation.
- **Solution:** start the backend; open `http://YOUR_COMPUTER_IP:3000/api/health` from your phone on the same Wi-Fi. If that fails, fix the items below.

## 5. localhost problem
- **Cause:** `localhost` on the ESP32 means the ESP32 itself.
- **Solution:** use `http://YOUR_COMPUTER_IP:3000/api/sensor` with your laptop's IPv4 address.

## 6. Windows Firewall
- **Cause:** Windows blocks incoming connections to port 3000.
- **Solution:** set your Wi-Fi network profile to **Private** (Settings → Network & internet → Wi-Fi → your network). Allow Node.js on Private networks when prompted, or in Administrator PowerShell:
  `New-NetFirewallRule -DisplayName "Node 3000" -Direction Inbound -Protocol TCP -LocalPort 3000 -Action Allow -Profile Private`
- Some routers also block device-to-device traffic ("AP/client isolation"); disable it or use a phone hotspot.

## 7. Wrong IP address
- **Cause:** the laptop's IP changed (the router assigns it automatically), or you copied the wrong adapter.
- **Solution:** run `ipconfig`, use the **IPv4 Address** under *Wireless LAN adapter Wi-Fi*, update `SERVER_URL`, upload again.

## 8. Backend won't start
- **Cause:** dependencies not installed, wrong folder, or a code error.
- **Solution:** run commands inside `backend/`: `npm install` then `npm start`. Read the first red error line in the terminal.

## 9. SQLite error
- **Cause:** `better-sqlite3` failed to install, the database is locked, or a corrupted file.
- **Solution:** use Node.js **LTS**; delete `backend/node_modules` and run `npm install` again; close any program that has the `.db` file open; as a last resort, stop the server and delete `backend/data/sensor.db` (this erases local data).

## 10. Dashboard cannot load
- **Cause:** backend not running or opened from the wrong address.
- **Solution:** start the backend and open `http://localhost:3000/`. Do not double-click `index.html`.

## 11. CORS issue
- **Cause:** page opened from a different origin than the API.
- **Solution:** open the dashboard through `http://localhost:3000/`. The backend already enables `cors()`. If you host the page elsewhere, set `API_BASE` in `frontend/js/script.js`.

## 12. Port 3000 already in use
- **Cause:** another program (or a second copy of the backend) uses port 3000.
- **Solution:** close the other terminal, or find the process: `netstat -ano | findstr :3000` then `taskkill /PID <number> /F`. Or set `PORT=3001` in `backend/.env` and update the URL in the ESP32 code.

## Extra: charts empty
- **Cause:** Chart.js is loaded from the internet.
- **Solution:** check your connection and reload. Cards and table still work without it.

## Extra: credentials committed to GitHub
- **Solution:** change your Wi-Fi password immediately, remove it from the code, and remove it from Git history. Deleting the line in a new commit is not enough.
